<!DOCTYPE html>
<html lang="en">
<link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
<script src="../js/jquery-1.12.4-jquery.min.js"></script>
<script src="../bootstrap/js/bootstrap.min.js"></script>
<style type="text/css">
	.login-form {
		width: 340px;
    	margin: 20px auto;
	}
    .login-form form {
    	margin-bottom: 15px;
        background: #f7f7f7;
        box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
        padding: 30px;
    }
    .login-form h2 {
        margin: 0 0 15px;
    }
    .form-control, .btn {
        min-height: 38px;
        border-radius: 2px;
    }
    .btn {        
        font-size: 15px;
        font-weight: bold;
    }
</style>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/main.css">
</head>
<body>
   <nav>
       <div class="logo">
           <img src="images/f_logo_RGB-Blue_72.png">
           <div class="search">
               <img src="images/search.svg">
               <input type="search" placeholder="Buscar en Worki">
           </div>
       </div>
       <div class="options">
           <img src="images/home.svg">
           <img src="images/friends.svg">
           <img src="images/flag.svg">
           <img src="images/video.svg">
           <img src="images/group.svg">
       </div>
       <div class="options-two">
           <div class="profile">
               <p>WORKI</p>
           </div>
            <img src="images/menu.svg">
            <img src="images/messenger.svg">
            <img src="images/notifications.svg">
            <img src="images/menu-desplegable.svg">
            <a href="../cerrar_sesion.php"><button class="btn btn-danger text-left"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button></a>
       </div>
   </nav>
   <top>
				<h1>Pagina personal</h1>
				
				<h3>
				<?php
				
				session_start();

				if(!isset($_SESSION['personal_login']))	
				{
					header("location: ../index.php");
				}

				if(isset($_SESSION['admin_login']))	
				{
					header("location: ../admin/admin_portada.php");
				}

				
				
				if(isset($_SESSION['personal_login']))
				{
				?>
					Bienvenido,
				<?php
					echo $_SESSION['personal_login'];
				}
				?>
				</h3>
			</top>




<!-- carrousel -->
<div id="carouselControls" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="multimedia/bg1.gif" class="d-block w-100" alt="">
    </div>
    <div class="carousel-item">
      <img src="multimedia/background.png" class="d-block w-100" alt="">
    </div>
    <div class="carousel-item">
      <img src="multimedia/diap 3.jpg" class="d-block w-100" alt="">
    </div>
  </div>
  <b class="carousel-control-prev"  href="#carouselControls"  role="button" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </b>
  <b class="carousel-control-next" href="#carouselControls" role="button"  data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </b>
</div>

            <!-- ribbon -->
<div id="ribbon" class="container-fluid">
  <div id="birthday" class="container w-50 pl-5 rounded">
    <div class="row align-items-center">
      <div class="col-sm p-3">
        <img src="multimedia/logo - copia.jpg" class="w-75 mx-auto d-block" alt="" >
      </div>
      <div class="col-sm p-3 text-light text-center">
        <p class="text-warning h3">Nothing to say</p>
        <h4 class="h2 text-shadow">Something ?</h4>
      </div>
    </div>
  </div>
</div>

<!-- separator -->
<div id="separator">
  <div class="content bg-secondary"></div>
</div>
<!-- other -->
<div id="blogs">
  <div class="container-md -5">

    <div class="row pt-5">
      <h3 class="text-center pb-5 pt-5 h1">Common Friends</h3>

    </div>
    <div class="row">
      <div class="col-sm">
        <div class="card w-100 card-border mb-5">
          <img src="multimedia/mask1.png" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title">Tony</h5>
            <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
            <a href="#" class="btn btn-primary">Go somewhere</a>
          </div>
        </div>
      </div>

      <div class="col-sm">
        <div class="card w-100 card-border mb-5">
          <img src="multimedia/mask2.png" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title">Louie</h5>
            <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
            <a href="#" class="btn btn-primary">Go somewhere</a>
          </div>
        </div>
      </div>
      <div class="col-sm">
        <div class="card w-100 card-border mb-5">
          <img src="multimedia/mask12.png" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title">Rasmus</h5>
            <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
            <a href="#" class="btn btn-primary">Go somewhere</a>
          </div>
        </div>
      </div>

      <div class="col-sm">
        <div class="card w-100 card-border mb-5">
          <img src="multimedia/mask11.png" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title">Richard</h5>
            <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
            <a href="#" class="btn btn-primary">Go somewhere</a>
          </div>
        </div>
      </div>
    </div>
    <div class="row py-5">
      
    </div>

</body>
</html>